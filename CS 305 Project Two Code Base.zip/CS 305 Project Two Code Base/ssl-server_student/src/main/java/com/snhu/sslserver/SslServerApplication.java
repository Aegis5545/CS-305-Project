package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
@RequestMapping("/hash")
class HashController {

    private static final String DEFAULT_NAME = "Cooper David";
    private static final String DATA = "Hello World Check Sum!";

    // Endpoint to return the checksum with your name
    @GetMapping
    public String getChecksum() {
        String checksum = generateChecksum(DATA);
        return generateResponse(checksum);
    }

    private String generateResponse(String checksum) {
        if (checksum == null || checksum.isEmpty()) {
            return "Error generating checksum.";
        }
        return "Hello " + DEFAULT_NAME + "!<br>Checksum: " + checksum;
    }

    // Method to generate checksum using SHA-256
    private String generateChecksum(String data) {
        if (data == null || data.isEmpty()) {
            return null;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "Error generating checksum";
        }
    }
}
